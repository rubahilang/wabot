// app.js
const express = require('express');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const session = require('express-session');
const axios = require('axios'); // Untuk HTTP requests
const cron = require('node-cron'); // Untuk penjadwalan
const https = require('https');

const app = express();
const PORT = 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));

app.use(express.json()); // Tambahkan middleware di sini
app.use(express.urlencoded({ extended: true }));


app.use(session({
    secret: 'secret_key', // Ganti dengan secret yang kuat
    resave: false,
    saveUninitialized: false
}));

// Path ke file users.json
const usersFile = path.join(__dirname, 'data', 'users.json');

// Fungsi untuk membaca users.json
function getUsers() {
    if (!fs.existsSync(usersFile)) {
        fs.writeFileSync(usersFile, JSON.stringify([]));
    }
    const data = fs.readFileSync(usersFile);
    return JSON.parse(data);
}

// Fungsi untuk menyimpan users.json
function saveUsers(users) {
    fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

// Middleware untuk melindungi route dan memeriksa status aktivasi
function isAuthenticated(req, res, next) {
    if (req.session.user) {
        const users = getUsers();
        const user = users.find(u => u.username === req.session.user.username);

        if (user) {
            // Cek apakah session expired atau key tidak valid
            if (user.activation.key) {
                const currentDate = new Date();
                const expiredDate = new Date(user.activation.expiredDate);
                if (currentDate > expiredDate) {
                    req.session.user.isActivated = false; // Tandai sebagai expired
                } else {
                    req.session.user.isActivated = true; // Tandai sebagai aktif
                }
            } else {
                req.session.user.isActivated = false; // Tandai sebagai tidak aktif
            }
            return next();
        }
    }
    res.redirect('/login');
}


function isActivated(req, res, next) {
    if (req.session.user && req.session.user.isActivated) {
        next();
    } else {
        res.status(403).send('Akses ditolak. Aktivasi diperlukan untuk menggunakan fitur ini.');
    }
}



// Route: GET /
app.get('/', (req, res) => {
    if (req.session.user) {
        res.redirect('/dashboard');
    } else {
        res.redirect('/login');
    }
});

// Route: GET /register
app.get('/register', (req, res) => {
    res.render('register', { message: null });
});

// Route: POST /register
app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    // Validasi input
    if (!username || !password) {
        return res.render('register', { message: 'Semua field wajib diisi.' });
    }

    const users = getUsers();

    // Cek apakah username sudah ada
    const existingUser = users.find(u => u.username === username);
    if (existingUser) {
        return res.render('register', { message: 'Username sudah digunakan.' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Buat objek pengguna baru dengan properti activation terinisialisasi
    const newUser = {
        username,
        password: hashedPassword,
        role: "", // Default role, bisa diubah sesuai kebutuhan
        nawalaInfo: [
            {
                "id": "1734631821337",
                "nama": "FOXY!",
                "domain": "foxproject.site",
                "status": "AMAN",
                "lastChecked": ""
              }
        ],
        activation: {
            key: "", // Kosongkan karena pengguna harus mengaktifkan dengan key
            role: "", // Akan diisi saat aktivasi
            activeUntil: "",
            expiredDate: ""
        }
    };

    // Tambahkan pengguna baru ke daftar pengguna
    users.push(newUser);
    saveUsers(users);

    res.render('login', { message: 'Registrasi berhasil. Silakan login.' });
});

// Route: GET /login
app.get('/login', (req, res) => {
    res.render('login', { message: null });
});
// Route: POST /login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    // Validasi input
    if (!username || !password) {
        return res.render('login', { message: 'Username dan password wajib diisi.' });
    }

    // Baca data pengguna
    const users = getUsers();
    const user = users.find(u => u.username === username);

    // Periksa apakah username ditemukan
    if (!user) {
        return res.render('login', { message: 'Username atau password salah.' });
    }

    // Periksa kecocokan password
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
        return res.render('login', { message: 'Username atau password salah.' });
    }

    // Simpan informasi pengguna di session
    req.session.user = {
        username: user.username,
        role: user.role
    };

    // Arahkan pengguna ke dashboard
    res.redirect('/dashboard');
});

// Route: POST /login
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    const users = getUsers();
    const user = users.find(u => u.username === username);

    if (!user) {
        return res.render('login', { message: 'Username atau password salah.' });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
        return res.render('login', { message: 'Username atau password salah.' });
    }

    req.session.user = {
        username: user.username,
        role: user.role
    };

    res.redirect('/dashboard');
});



// Route: GET /dashboard
app.get('/dashboard', isAuthenticated, (req, res) => {
    const users = getUsers();
    const user = users.find(u => u.username === req.session.user.username);

    let activationStatus = null;
    if (!req.session.user.isActivated) {
        activationStatus = 'Akun Anda belum diaktivasi atau session telah kadaluwarsa. Beberapa fitur mungkin tidak tersedia.';
    }

    res.render('dashboard', { user, activationStatus });
});


// Route: GET /nawainfo
app.get('/nawainfo', (req, res) => {
    const users = getUsers();

    // Validasi sesi pengguna
    const currentUser = req.session.user
        ? users.find(user => user.username === req.session.user.username)
        : null;

    if (!currentUser) {
        return res.status(401).send('Anda harus login untuk mengakses halaman ini.');
    }

    const { filter, search } = req.query;
    let nawainfo = currentUser.nawalaInfo;

    // Filter berdasarkan status
    if (filter === 'AMAN') {
        nawainfo = nawainfo.filter(info => info.status === 'AMAN');
    } else if (filter === 'IPOS') {
        nawainfo = nawainfo.filter(info => info.status === 'IPOS');
    }

    // Sortir
    if (filter === 'A-Z') {
        nawainfo.sort((a, b) => a.nama.localeCompare(b.nama));
    } else if (filter === 'Last Check') {
        nawainfo.sort((a, b) => new Date(b.lastChecked) - new Date(a.lastChecked));
    }

    // Pencarian
    if (search) {
        const searchLower = search.toLowerCase();
        nawainfo = nawainfo.filter(info =>
            info.nama.toLowerCase().includes(searchLower) ||
            info.domain.toLowerCase().includes(searchLower)
        );
    }

    // Cek apakah ada status IPOS
    const hasIpos = nawainfo.some(info => info.status === 'IPOS');

    res.render('nawainfo', { user: currentUser, nawainfo, message: null, filter, search, hasIpos });
});


// Fungsi untuk memeriksa status domain
async function checkDomainStatus(domain) {
    try {
        // Kirim permintaan GET ke URL untuk memeriksa blokir
        const url = 'https://check.skiddle.id/';
        const params = { domains: domain };
        const response = await axios.get(url, { params });

        // Parsing respons sesuai struktur API
        if (response.data && response.data[domain] && typeof response.data[domain].blocked === 'boolean') {
            return response.data[domain].blocked ? 'IPOS' : 'AMAN';
        } else {
            return 'unknown';
        }
    } catch (error) {
        console.error(`Error checking domain ${domain}:`, error.message);
        return 'unknown';
    }
}


// Route: POST /nawainfo/add
app.post('/nawainfo/add', isAuthenticated, isActivated, async (req, res) => {
    const { nama, domain } = req.body;

    // Validasi sederhana
    if (!nama || !domain) {
        const users = getUsers();
        const currentUser = users.find(user => user.username === req.session.user.username);
        return res.render('nawainfo', { user: currentUser, message: 'Nama dan Domain wajib diisi.' });
    }

    // Validasi format domain (contoh sederhana)
    const domainRegex = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)+[a-zA-Z]{2,11}?$/;
    if (!domainRegex.test(domain)) {
        const users = getUsers();
        const currentUser = users.find(user => user.username === req.session.user.username);
        return res.render('nawainfo', { user: currentUser, message: 'Format Domain tidak valid.' });
    }

    // Periksa status domain
    const status = await checkDomainStatus(domain);
    const lastChecked = new Date().toLocaleString();

    const users = getUsers();
    const currentUserIndex = users.findIndex(user => user.username === req.session.user.username);

    if (currentUserIndex !== -1) {
        const newId = Date.now().toString(); // Atau gunakan UUID
        const newEntry = {
            id: newId,
            nama,
            domain,
            status,
            lastChecked
        };
        // Pastikan nawalaInfo terdefinisi dan merupakan array
        if (!Array.isArray(users[currentUserIndex].nawalaInfo)) {
            users[currentUserIndex].nawalaInfo = [];
        }
        users[currentUserIndex].nawalaInfo.push(newEntry);
        saveUsers(users);
        res.redirect('/nawainfo');
    } else {
        res.render('nawainfo', { user: req.session.user, message: 'User tidak ditemukan.' });
    }
});


// Route: GET /nawainfo/edit/:id
app.get('/nawainfo/edit/:id', isAuthenticated, isActivated, (req, res) => {
    const { id } = req.params;
    const users = getUsers();
    const currentUser = users.find(user => user.username === req.session.user.username);
    const entry = currentUser.nawalaInfo.find(item => item.id === id);

    if (entry) {
        res.render('edit_nawainfo', { user: currentUser, entry, message: null });
    } else {
        res.redirect('/nawainfo');
    }
});

// Route: POST /nawainfo/edit/:id
app.post('/nawainfo/edit/:id', isAuthenticated, isActivated, async (req, res) => {
    const { id } = req.params;
    const { nama, domain, status } = req.body;

    // Validasi input
    if (!nama || !domain || !status) {
        const users = getUsers();
        const currentUser = users.find(user => user.username === req.session.user.username);
        const entry = currentUser.nawalaInfo.find(item => item.id === id);
        return res.render('edit_nawainfo', { user: currentUser, entry, message: 'Semua field wajib diisi.' });
    }

    // Validasi format domain
    const domainRegex = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)+[a-zA-Z]{2,11}?$/;
    if (!domainRegex.test(domain)) {
        const users = getUsers();
        const currentUser = users.find(user => user.username === req.session.user.username);
        const entry = currentUser.nawalaInfo.find(item => item.id === id);
        return res.render('edit_nawainfo', { user: currentUser, entry, message: 'Format Domain tidak valid.' });
    }

    // Periksa status domain
    const newStatus = await checkDomainStatus(domain);
    const lastChecked = new Date().toLocaleString();

    const users = getUsers();
    const currentUserIndex = users.findIndex(user => user.username === req.session.user.username);

    if (currentUserIndex !== -1) {
        const entryIndex = users[currentUserIndex].nawalaInfo.findIndex(item => item.id === id);
        if (entryIndex !== -1) {
            users[currentUserIndex].nawalaInfo[entryIndex] = { id, nama, domain, status: newStatus, lastChecked };
            saveUsers(users);
            res.redirect('/nawainfo');
        } else {
            res.redirect('/nawainfo');
        }
    } else {
        res.redirect('/nawainfo');
    }
});


// Route: POST /nawainfo/delete/:id
app.post('/nawainfo/delete/:id', isAuthenticated, isActivated, (req, res) => {
    const { id } = req.params;
    const users = getUsers();
    const currentUserIndex = users.findIndex(user => user.username === req.session.user.username);

    if (currentUserIndex !== -1) {
        users[currentUserIndex].nawalaInfo = users[currentUserIndex].nawalaInfo.filter(item => item.id !== id);
        saveUsers(users);
        res.redirect('/nawainfo');
    } else {
        res.redirect('/nawainfo');
    }
});

// Route: GET /tlyrouting
app.get('/tlyrouting', isAuthenticated, (req, res) => {
    res.render('tlyrouting', { user: req.session.user });
});

// Anda dapat menambahkan route dan tampilan serupa untuk Rank Checker dan Phising Report

// Route: GET /logout
app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/dashboard');
        }
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
});

// Fungsi untuk melakukan pemeriksaan status domain setiap 10 menit
cron.schedule('*/10 * * * *', async () => {
    console.log('Memulai pemeriksaan status domain...');

    const users = getUsers();
    let updated = false;

    for (let user of users) {
        if (Array.isArray(user.nawalaInfo)) {
            for (let entry of user.nawalaInfo) {
                const { domain } = entry;
                const status = await checkDomainStatus(domain);
                const lastChecked = new Date().toLocaleString();

                if (entry.status !== status || !entry.lastChecked) {
                    entry.status = status;
                    entry.lastChecked = lastChecked;
                    updated = true;
                    console.log(`Memperbarui status domain ${domain} untuk pengguna ${user.username}`);
                } else {
                    // Update lastChecked tetap dilakukan
                    entry.lastChecked = lastChecked;
                    updated = true;
                }
            }
        }
    }

    if (updated) {
        saveUsers(users);
        console.log('Pemeriksaan status domain selesai dan data diperbarui.');
    } else {
        console.log('Tidak ada perubahan status domain.');
    }
});

// Route: GET /activation
app.get('/activation', isAuthenticated, (req, res) => {
    const message = req.query.message || null;
    const users = getUsers();
    const user = users.find(u => u.username === req.session.user.username);
    res.render('activation', { message, user });
});


const activationKeysFile = path.join(__dirname, 'data', 'activation_keys.json');

// Fungsi untuk membaca activation_keys.json
function getActivationKeys() {
    if (!fs.existsSync(activationKeysFile)) {
        fs.writeFileSync(activationKeysFile, JSON.stringify([]));
    }
    const data = fs.readFileSync(activationKeysFile);
    return JSON.parse(data);
}

// Fungsi untuk menyimpan activation_keys.json
function saveActivationKeys(keys) {
    fs.writeFileSync(activationKeysFile, JSON.stringify(keys, null, 2));
}


// Route: POST /activation
app.post('/activation', isAuthenticated, (req, res) => {
    const { key } = req.body;
    const activationKeys = getActivationKeys();
    const activationKey = activationKeys.find(k => k.key === key);

    if (!activationKey) {
        const message = 'Activation key tidak valid.';
        const users = getUsers();
        const user = users.find(u => u.username === req.session.user.username);
        return res.render('activation', { message, user });
    }

    // Cek apakah key sudah digunakan oleh pengguna lain
    const users = getUsers();
    const existingUser = users.find(u => u.activation.key === key);

    if (existingUser) {
        const message = 'Activation key sudah digunakan oleh pengguna lain.';
        const user = users.find(u => u.username === req.session.user.username);
        return res.render('activation', { message, user });
    }

    const currentDate = new Date();
    const activeUntil = new Date(activationKey.activeUntil);
    const expiredDate = new Date(activationKey.expiredDate);

    if (currentDate > expiredDate) {
        const message = 'Activation key telah expired.';
        const user = users.find(u => u.username === req.session.user.username);
        return res.render('activation', { message, user });
    }

    // Assign activation to user
    const user = users.find(u => u.username === req.session.user.username);
    if (!user) {
        const message = 'User tidak ditemukan.';
        return res.render('activation', { message, user: null });
    }

    user.activation = {
        key: activationKey.key,
        role: activationKey.role,
        activeUntil: activationKey.activeUntil,
        expiredDate: activationKey.expiredDate
    };

    saveUsers(users);

    res.redirect('/dashboard');
});



// Middleware untuk memeriksa apakah pengguna adalah admin
function isAdmin(req, res, next) {
    if (req.session.user && req.session.user.role === 'admin') {
        next();
    } else {
        res.status(403).send('Forbidden');
    }
}

// Route: GET /admin/keys
app.get('/admin/keys', isAuthenticated, isAdmin, (req, res) => {
    const activationKeys = getActivationKeys();
    res.render('admin_keys', { activationKeys, message: null, user: req.session.user });
});

// Route: POST /admin/keys
app.post('/admin/keys', isAuthenticated, isAdmin, (req, res) => {
    const { role, activeUntil, expiredDate } = req.body;

    // Validasi input
    if (!role || !activeUntil || !expiredDate) {
        const activationKeys = getActivationKeys();
        return res.render('admin_keys', { activationKeys, message: 'Semua field wajib diisi.', user: req.session.user });
    }

    // Generate activation key
    const key = generateRandomKey(8);
    const newKey = {
        key,
        role,
        activeUntil,
        expiredDate
    };

    const activationKeys = getActivationKeys();
    activationKeys.push(newKey);
    saveActivationKeys(activationKeys);

    res.redirect('/admin/keys');
});


// Fungsi untuk menghasilkan activation key acak
function generateRandomKey(length) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Contoh server-side (Express.js)
app.get('/rankchecker', isAuthenticated, async (req, res) => {
    const users = getUsers();
    let currentUser = users.find(user => user.username === req.session.user.username);

    // Log untuk debugging
    console.log('Current User:', currentUser);

    // Pastikan properti activation ada
    if (!currentUser.activation) {
        currentUser.activation = {}; // Atau inisialisasi sesuai kebutuhan
    }

    res.render('rankchecker', {
        user: currentUser,
        message: null,
        results: null,
        query: '',
        device: ''
    });
});


// Route POST untuk memproses form rankchecker
app.post('/rankchecker', isAuthenticated, async (req, res) => {
    const { query, device } = req.body;

    // Validasi input
    if (!query || !device) {
        console.error('Query atau Device tidak ditemukan.');
        return res.render('rankchecker', {
            user: req.session.user,
            message: 'Masukkan Query dan Device yang valid.',
            results: null,
            query: query || '',
            device: device || ''
        });
    }

    // Data yang dikirim ke API
    const data = {
        data: {
            q: query, // Kata kunci pencarian
            domain: "google.com", // Domain target
            lang: "id", // Bahasa
            country: "ID",
            device: device, // Perangkat (mobile/desktop)
            serp_type: "web", // Jenis pencarian
            loc: "Indonesia", // Lokasi
            verbatim: "0", // Verbatim mode
            gfilter: "0", // Filter
            page: "1", // Halaman
            num_result: "20" // Jumlah hasil per halaman
        }
    };

    // Konfigurasi request ke API
    const config = {
        method: 'post',
        url: 'https://api.serphouse.com/serp/live',
        headers: { 
            'Content-Type': 'application/json', 
            'Authorization': 'Bearer QM6N4VrRBvmWQksoXLUWomeO3sEoJBtYzr4F6oXhircOVllyyI6dsnKcoWWa' // API key Anda
        },
        data: data
    };

    try {
        const response = await axios(config);
        console.log('API Response:', JSON.stringify(response.data, null, 2));
        res.render('rankchecker', {
            user: req.session.user,
            message: null,
            results: response.data,
            query,
            device
        });
    } catch (error) {
        console.error('API Request Error:', error.response ? error.response.data : error.message);
        res.render('rankchecker', {
            user: req.session.user,
            message: error.response?.data?.msg || 'Terjadi kesalahan saat menghubungi API.',
            results: null,
            query,
            device
        });
    }
});



app.get('/phishingreport', isAuthenticated, async (req, res) => {
    const { filter, search } = req.query;
    const users = getUsers();
    let currentUser = users.find(user => user.username === req.session.user.username);
    let phishingreport = currentUser.phishingreport;
    res.render('phishingreport', {
         user: currentUser, 
         phishingreport, 
         message: null, 
         filter, 
         search,
         result: null  // Pastikan ini sesuai dengan EJS template
    });
});


// Route untuk memproses laporan phishing
app.post('/phishingreport', async (req, res) => {
    const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY || "AIzaSyAb4MlukiqcUftRR86SRcA18iQLGsvSy5Q"; // Disarankan menggunakan environment variables
    const { urls } = req.body;

    if (!urls || urls.trim() === "") {
        return res.render('phishingreport', {
            user: req.session.user || {},
            message: { text: "Silakan masukkan URL untuk dilaporkan.", type: 'error' },
            result: null
        });
    }

    // Memisahkan URL berdasarkan baris baru dan membersihkan input
    const urlList = urls.split('\n').map(url => url.trim()).filter(url => url !== "");

    if (urlList.length === 0) {
        return res.render('phishingreport', {
            user: req.session.user || {},
            message: { text: "Tidak ada URL valid yang ditemukan.", type: 'error' },
            result: null
        });
    }

    const endpoint = `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${GOOGLE_API_KEY}`;
    const clientInfo = {
        client: {
            clientId: "reportphishing-443815",
            clientVersion: "1.5.2"
        }
    };

    let result = [];

    try {
        for (let i = 0; i < urlList.length; i++) {
            const url = urlList[i];
            const body = {
                ...clientInfo,
                threatInfo: {
                    threatTypes: ["SOCIAL_ENGINEERING", "MALWARE"],
                    platformTypes: ["ANY_PLATFORM"],
                    threatEntryTypes: ["URL"],
                    threatEntries: [{ url }]
                }
            };

            try {
                const response = await axios.post(endpoint, body, {
                    headers: { "Content-Type": "application/json" }
                });

                const apiResult = response.data;

                if (Object.keys(apiResult).length === 0) {
                    result.push({
                        url,
                        status: 'success',
                        detail: 'URL berhasil dilaporkan!'
                    });
                } else {
                    result.push({
                        url,
                        status: 'failed',
                        detail: JSON.stringify(apiResult, null, 2)
                    });
                }
            } catch (error) {
                console.error(`Error melaporkan URL: ${url}`, error);
                result.push({
                    url,
                    status: 'failed',
                    detail: `Terjadi kesalahan: ${error.response ? error.response.statusText : error.message}`
                });
            }
        }

        res.render('phishingreport', {
            user: req.session.user || {},
            message: { text: "Laporan telah diproses.", type: 'success' },
            result
        });

    } catch (error) {
        console.error('Error saat memproses laporan:', error);
        res.render('phishingreport', {
            user: req.session.user || {},
            message: { text: `Terjadi kesalahan saat memproses laporan: ${error.message}`, type: 'error' },
            result: null
        });
    }
});

// Route: GET /nawadd
app.get('/nawadd', async (req, res) => {
    const { user: username, name, domain } = req.query;

    // Validasi parameter
    if (!username || !name || !domain) {
        return res.status(400).send('Parameter "user", "name", dan "domain" wajib diisi.');
    }

    // Validasi format domain
    const domainRegex = /^(?!:\/\/)([a-zA-Z0-9-_]+\.)+[a-zA-Z]{2,11}?$/;
    if (!domainRegex.test(domain)) {
        return res.status(400).send('Format domain tidak valid.');
    }

    // Simulasi fungsi untuk memeriksa status domain
    const checkDomainStatus = async (domain) => {
        return 'AMAN'; // Simulasi respons
    };

    // Periksa status domain
    const status = await checkDomainStatus(domain);
    const lastChecked = new Date().toLocaleString();

    // Fungsi untuk membaca file JSON
    const getUsers = () => {
        const data = fs.readFileSync('./data/users.json', 'utf8');
        return JSON.parse(data);
    };

    // Fungsi untuk menyimpan file JSON
    const saveUsers = (users) => {
        fs.writeFileSync('./data/users.json', JSON.stringify(users, null, 2));
    };

    // Baca data pengguna dari file JSON
    const users = getUsers();
    const userIndex = users.findIndex((u) => u.username === username);

    if (userIndex === -1) {
        return res.status(404).send('User tidak ditemukan.');
    }

    const newId = Date.now().toString(); // ID unik
    const newEntry = {
        id: newId,
        nama: name,
        domain,
        status,
        lastChecked
    };

    // Pastikan `nawalaInfo` adalah array
    if (!Array.isArray(users[userIndex].nawalaInfo)) {
        users[userIndex].nawalaInfo = [];
    }

    // Tambahkan entri baru ke `nawalaInfo`
    users[userIndex].nawalaInfo.push(newEntry);

    // Simpan perubahan ke file JSON
    saveUsers(users);

    res.send('Domain berhasil ditambahkan!');
});

app.post('/check-status', async (req, res) => {
    const { username } = req.body;

    if (!username) {
        return res.status(400).json({ error: 'Username tidak disediakan.' });
    }

    const users = getUsers();
    const user = users.find(u => u.username === username);

    if (!user) {
        return res.status(404).json({ error: 'User tidak ditemukan.' });
    }

    let hasIpos = false;

    for (const info of user.nawalaInfo) {
        const newStatus = await checkDomainStatus(info.domain); // Memeriksa status domain
        info.status = newStatus;
        info.lastChecked = new Date().toLocaleString();

        if (newStatus === 'IPOS') {
            hasIpos = true;
        }
    }

    saveUsers(users); // Simpan perubahan ke JSON

    res.json({ message: 'Pemeriksaan selesai.', hasIpos }); // Kembalikan hasil
});


// Mulai server
app.listen(PORT, () => {
    console.log(`Server berjalan di http://localhost:${PORT}`);
});
